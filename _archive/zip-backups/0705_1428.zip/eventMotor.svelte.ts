import { spilTilstand } from './spilTilstand.svelte';
import { eventBibliotek } from './eventBibliotek';
import { tilfoejTilRygsæk, brugFraRygsæk } from './spilmotor';
import { syncTilDb } from './netvaerk';
import { fremrykTid } from './overlevelse.svelte';
import type { Valg } from './eventBibliotek';

export const eventState = $state({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    aktivt: null as any,
    log: [] as string[],
    valgLåst: false,
    naesteTrin: null as string | null,
    erFaerdig: false,
    afventerKollaps: false
});

export function startEvent(eventID: string) {
    const evt = eventBibliotek[eventID];
    if (!evt) return;
    
    eventState.aktivt = evt;
    eventState.log = [evt.tekst];
    
    spilTilstand.logBesked = `--- ${evt.titel.toUpperCase()} ---`;
    spilTilstand.logBesked = evt.tekst;
    
    eventState.valgLåst = false;
    eventState.naesteTrin = null;
    eventState.erFaerdig = false;
    eventState.afventerKollaps = false;
}

export function lukEvent() {
    eventState.aktivt = null;
    eventState.log = [];
    eventState.valgLåst = false;
    eventState.naesteTrin = null;
    eventState.erFaerdig = false;
    eventState.afventerKollaps = false;
}

export function kanViseValg(valg: Valg) {
    if (valg.kraeverKarakter && spilTilstand.valgtKarakter?.id !== valg.kraeverKarakter) return false;
    if (valg.puljeVaerdi && spilTilstand.guldTotal < valg.puljeVaerdi) return false;

    if (valg.kraeverItem) {
        const harTing = spilTilstand.mitUdstyr?.find(i => i.id === valg.kraeverItem);
        if (!harTing || harTing.maengde <= 0) return false;
    }

    if (valg.kosterItem) {
        const harTing = spilTilstand.mitUdstyr?.find(i => i.id === valg.kosterItem);
        if (!harTing || harTing.maengde <= 0) return false;
    }

    return true;
}

export function tagValg(valg: Valg) {
    if (eventState.valgLåst) return;

    if (!kanViseValg(valg)) {
        eventState.log = [...eventState.log, "Du har ikke det nødvendige udstyr eller guld."];
        return;
    }

    if (valg.kosterItem) {
        brugFraRygsæk(valg.kosterItem, 1);
    }
    if (valg.puljeVaerdi) {
        spilTilstand.guldTotal -= valg.puljeVaerdi;
    }

    eventState.valgLåst = true;

    if (valg.udfaldListe && valg.udfaldListe.length > 0) {
        const resultat = valg.udfaldListe[Math.floor(Math.random() * valg.udfaldListe.length)];
        let kvittering = "";
        let samletLogTekst = resultat.log;

        if (resultat.maxHpAendring) {
            spilTilstand.maxLivspoint += resultat.maxHpAendring;
            spilTilstand.livspoint += (resultat.maxHpAendring > 0 ? resultat.maxHpAendring : 0);
            kvittering += ` (${resultat.maxHpAendring > 0 ? '+' : ''}${resultat.maxHpAendring} Max HP)`;
        }

        if (resultat.hpAendring) {
            let endeligHp = resultat.hpAendring;
            const udsving = Math.abs(endeligHp * 0.25);
            endeligHp = Math.round(endeligHp + (Math.random() * udsving * 2) - udsving);
            
            if (endeligHp < 0) {
                endeligHp = -spilTilstand.beregnSkade(Math.abs(endeligHp));
            }
            
            const foerHp = spilTilstand.livspoint;
            spilTilstand.livspoint += endeligHp;
            const faktiskAendring = spilTilstand.livspoint - foerHp;
            
            if (faktiskAendring !== 0) {
                kvittering += ` (${faktiskAendring > 0 ? '+' : ''}${faktiskAendring} HP)`;
            } else if (endeligHp > 0) {
                kvittering += ` (Allerede fuld HP)`;
            }
        }

        if (resultat.guldAendring) {
            let endeligGuld = resultat.guldAendring;
            const udsving = Math.abs(endeligGuld * 0.25);
            endeligGuld = Math.round(endeligGuld + (Math.random() * udsving * 2) - udsving);

            if (endeligGuld > 0) {
                endeligGuld = spilTilstand.beregnGuldIndkomst(endeligGuld);
            }

            const foerGuld = spilTilstand.guldTotal;
            spilTilstand.guldTotal += endeligGuld;
            const faktiskGuldAendring = spilTilstand.guldTotal - foerGuld;

            if (faktiskGuldAendring !== 0) {
                kvittering += ` (${faktiskGuldAendring > 0 ? '+' : ''}${faktiskGuldAendring} Guld)`;
            }
        }

        if (kvittering) {
            samletLogTekst += kvittering;
        }

        eventState.log = [...eventState.log, samletLogTekst];
        spilTilstand.logBesked = samletLogTekst;

        if (resultat.givItem) tilfoejTilRygsæk(resultat.givItem, 1);
        if (resultat.mistItem) brugFraRygsæk(resultat.mistItem, 1);

        syncTilDb(true);

        if (resultat.kollaps || spilTilstand.livspoint <= 0) {
            eventState.afventerKollaps = true;
            return;
        }

        if (resultat.naesteTrin) {
            eventState.naesteTrin = resultat.naesteTrin;
        } else {
            const felt = spilTilstand.gitter[spilTilstand.spillerIndex];
            if (felt) felt.eventFuldført = true;
            syncTilDb(true);
            fremrykTid();
            eventState.erFaerdig = true;
        }
    } 
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    else if ((valg as any).effekt) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const resultat = (valg as any).effekt();
        eventState.log = [...eventState.log, resultat.logBesked];
        spilTilstand.logBesked = resultat.logBesked;

        if (resultat.hpOp) spilTilstand.livspoint += resultat.hpOp;
        if (resultat.hpNed) spilTilstand.livspoint -= spilTilstand.beregnSkade(resultat.hpNed);
        if (resultat.guldOp) spilTilstand.guldTotal += spilTilstand.beregnGuldIndkomst(resultat.guldOp);
        if (resultat.guldNed) spilTilstand.guldTotal -= resultat.guldNed;
        if (resultat.itemUd) tilfoejTilRygsæk(resultat.itemUd, 1);
        
        syncTilDb(true);

        if (spilTilstand.livspoint <= 0) {
            eventState.afventerKollaps = true;
            return;
        }

        if (resultat.naesteEvent) {
            eventState.naesteTrin = resultat.naesteEvent;
        } else {
            const felt = spilTilstand.gitter[spilTilstand.spillerIndex];
            if (felt) felt.eventFuldført = true;
            syncTilDb(true);
            fremrykTid();
            eventState.erFaerdig = true;
        }
    } else {
        eventState.log = [...eventState.log, "Ingenting skete."];
        spilTilstand.logBesked = "Ingenting skete.";
        const felt = spilTilstand.gitter[spilTilstand.spillerIndex];
        if (felt) felt.eventFuldført = true;
        syncTilDb(true);
        fremrykTid();
        eventState.erFaerdig = true;
    }
}