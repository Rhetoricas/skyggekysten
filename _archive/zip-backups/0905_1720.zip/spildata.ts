import type { Karakter, Biome, ItemType } from './types';

export const BREDDE = 100;
export const HOEJDE = 20;
export const HEX_W = 96;  
export const ROW_H = 82; 

export const biomeVægte: Array<{ id: Biome; vaegt: number }> = [
    { id: 'mark', vaegt: 20 }, { id: 'eng', vaegt: 20 }, { id: 'skov', vaegt: 20 }, { id: 'bjerg', vaegt: 20 },
    { id: 'hule', vaegt: 2 }, { id: 'ritual', vaegt: 2 }, { id: 'ruin', vaegt: 2 }, { id: 'bandit', vaegt: 2 },
    { id: 'hoejland', vaegt: 15 }, { id: 'blodskov', vaegt: 5 }, { id: 'hav', vaegt: 10 },
    { id: 'krystal', vaegt: 5 }, { id: 'slagmark', vaegt: 5 }
];

export const biomeTerraenCost: Record<Biome, number> = {
    'mark': 1, 'eng': 1, 'by': 0, 'marked': 0,
    'skov': 3, 'ruin': 3, 'ritual': 3, 'bandit': 2, 'hoejland': 2, 'slagmark': 2,
    'bjerg': 5, 'blodskov': 4, 'hule': 4, 'krystal': 4,
    'hav': 5
};

export const markedVarePool = ['skovl', 'livseliksir', 'klude', 'kniv', 'metaldetektor', 'soegekvist', 'fakkel', 'sovepose', 'mad'];

export const itemDB: Record<string, { id: string; navn: string; type: ItemType; billede: string; pris: number; moveMod?: number; dmgMod?: number; synsMod?: number; energiMod?: number; goldMod?: number; beskrivelse?: string }> = {
    'klude': { id: 'klude', navn: 'Klude', type: 'tøj', billede: '/inventory/klude.webp', pris: 10, dmgMod: -0.05, beskrivelse: "Giver en smule beskyttelse. Du tager 5% mindre skade." },
    'rustning': { id: 'rustning', navn: 'Rustning', type: 'tøj', billede: '/inventory/rustning.webp', pris: 150, moveMod: 1, dmgMod: -0.50, beskrivelse: "Halverer al skade, men den tunge vægt koster dig 1 energi pr. skridt. Synker til bunds og forsvinder, hvis du går i vandet." },
    'flot_toej': { id: 'flot_toej', navn: 'Fint tøj', type: 'tøj', billede: '/inventory/flot_toej.webp', pris: 120, dmgMod: -0.05, goldMod: 0.15, beskrivelse: "Øger al din guldindkomst med 15%. Skarpe sten og torne flænser det fine tøj til klude i huler og blodskov." },
    'kniv': { id: 'kniv', navn: 'Kniv', type: 'våben', billede: '/inventory/kniv.webp', pris: 40, beskrivelse: "Det mindste våben, som mest fungerer i specielle situationer." },
    'stav': { id: 'stav', navn: 'Stav', type: 'våben', billede: '/inventory/stav.webp', pris: 100, beskrivelse: "Kan bruges som våben, men fungerer også som teleporter. Du ryger blindt 4 felter mod øst. Koster din base-energi og koster liv, hvis du lander på en bjergtop eller i en fælde (eller i vand)." },
    'bue': { id: 'bue', navn: 'Bue', type: 'våben', billede: '/inventory/bue.webp', pris: 60, beskrivelse: "God til at nedlægge specifikke trusler på afstand." },
    'oekse': { id: 'oekse', navn: 'Økse', type: 'våben', billede: '/inventory/oekse.webp', pris: 80, beskrivelse: "Et tungt og brutalt våben." },
    'svaerd': { id: 'svaerd', navn: 'Sværd', type: 'våben', billede: '/inventory/svaerd.webp', pris: 80, beskrivelse: "Det klassiske valg for krigere." },
    'sabel': { id: 'sabel', navn: 'Sabel', type: 'våben', billede: '/inventory/sabel.webp', pris: 60, beskrivelse: "En klinge, der egner sig til kystens farer." },
    'skovl': { id: 'skovl', navn: 'Skovl', type: 'værktøj', billede: '/inventory/skovl.webp', pris: 60, beskrivelse: "Lader dig grave guld og helende rødder op. Uden skovl kan det blive dyrt at grave." },
    'metaldetektor': { id: 'metaldetektor', navn: 'Detektor', type: 'værktøj', billede: '/inventory/detector.webp', pris: 150, beskrivelse: "Viser hvor skjult guld ligger. Går du ind i et krystalfelt kortslutter den og bliver ødelagt." },
    'soegekvist': { id: 'soegekvist', navn: 'Søgekvist', type: 'værktøj', billede: '/inventory/oenskekvist.webp', pris: 150, beskrivelse: "Viser hvor de helende rødder ligger. Mørk magi brænder den til aske på ritual-felter." },
    'livseliksir': { id: 'livseliksir', navn: 'Livseliksir', type: 'forbrug', billede: '/inventory/livseliksir.webp', pris: 500, beskrivelse: "Drikkes automatisk, hvis du får dødelig skade. Heler dig maksimalt tilbage til 90 HP." },
    'fakkel': { id: 'fakkel', navn: 'Fakkel', type: 'værktøj', billede: '/inventory/fakkel.webp', pris: 150, synsMod: 1, beskrivelse: "Udvider dit synsfelt med +1. Kan bruges til store lejrbål, som alle kan se. Går tabt i vandet." },
    'sovepose': { id: 'sovepose', navn: 'Sovepose', type: 'værktøj', billede: '/inventory/sovepose.webp', pris: 80, beskrivelse: "Slå lejr i vildmarken og få 20 HP (koster resten af din energi). Fugt i huler får den til at rådne med det samme." },
    'mad': { id: 'mad', navn: 'Madration', type: 'forbrug', billede: '/inventory/food.webp', pris: 30, beskrivelse: "Medbragt mad, der giver +10 HP og +1 Energi. Bliver stjålet og spist af skadedyr, hvis du tager det med i et ruin-felt." },
    'kikkert_250': { id: 'kikkert_250', navn: 'Gylden Kikkert', type: 'forbandelse', billede: '/inventory/kikkert.webp', pris: 100, beskrivelse: "Krystallernes lys splintrer dens linser i krystal-felter." },
    'kikkert_45': { id: 'kikkert_45', navn: 'Gylden Kikkert', type: 'forbandelse', billede: '/inventory/kikkert.webp', pris: 100, beskrivelse: "Krystallernes lys splintrer dens linser i krystal-felter." },
    'diamant': { id: 'diamant', navn: 'Diamant', type: 'skat', billede: '/inventory/diamant.webp', pris: 500, beskrivelse: "En sjælden og værdifuld ædelsten, der nemt kan sælges." }
}

export const tilgaengeligeKarakterer: Karakter[] = [
    { id: 'knight_m', navn: "Ridder", ikon: "/game_faces/knight_m.webp", startMsg: "Rustningen tynger, men beskytter.", startHp: 120, startGuld: 0, startUdstyr: ['svaerd', 'rustning', 'sovepose'], moveCost: 1, digCost: 6, dmgMod: 0.9, goldMod: 1.0, fordel: "Starter med sværd og rustning.", ulempe: "Tungt udstyr gør dig langsom.", baseEnergi: 7, synsRadius: 1, biomeMod: { 'slagmark': -2 } },
    { id: 'knight_f', navn: "Skjoldmø", ikon: "/game_faces/knight_f.webp", startMsg: "Rustningen tynger, men beskytter.", startHp: 120, startGuld: 0, startUdstyr: ['svaerd', 'rustning', 'sovepose'], moveCost: 1, digCost: 6, dmgMod: 0.9, goldMod: 1.0, fordel: "Starter med sværd og rustning.", ulempe: "Tungt udstyr gør dig langsom.", baseEnergi: 7, synsRadius: 1, biomeMod: { 'slagmark': -2 } },
    { id: 'magician_m', navn: "Troldmand", ikon: "/game_faces/magician_m.webp", startMsg: "Magi beskytter ikke mod mudder.", startHp: 80, startGuld: 0, startUdstyr: ['stav', 'klude', 'livseliksir', 'sovepose'], moveCost: 1, digCost: 8, dmgMod: 1.5, goldMod: 1.0, fordel: "Starter med en livseliksir og en stav.", ulempe: "Starter uden guld og tager +50% skade.", baseEnergi: 7, synsRadius: 1, biomeMod: { 'krystal': -2 } },  
    { id: 'magician_f', navn: "Troldkvinde", ikon: "/game_faces/magician_f.webp", startMsg: "Magi beskytter ikke mod mudder.", startHp: 80, startGuld: 0, startUdstyr: ['stav', 'klude', 'livseliksir', 'sovepose'], moveCost: 1, digCost: 8, dmgMod: 1.5, goldMod: 1.0, fordel: "Starter med en livseliksir og en stav.", ulempe: "Starter uden guld og tager +50% skade.", baseEnergi: 7, synsRadius: 1, biomeMod: { 'krystal': -2 } },
    { id: 'thief_m', navn: "Tyv", ikon: "/game_faces/thief_m.webp", startMsg: "Hold dig i bevægelse.", startHp: 100, startGuld: 50, startUdstyr: ['kniv', 'klude', 'sovepose'], moveCost: 1, digCost: 5, dmgMod: 1.2, goldMod: 1.1, fordel: "Hurtig og udstyret med en kniv.", ulempe: "Tager mere skade.", baseEnergi: 9, synsRadius: 1, biomeMod: { 'bandit': -2 } },
    { id: 'thief_f', navn: "Skygge", ikon: "/game_faces/thief_f.webp", startMsg: "Hold dig i bevægelse.", startHp: 100, startGuld: 50, startUdstyr: ['kniv', 'klude', 'sovepose'], moveCost: 1, digCost: 5, dmgMod: 1.2, goldMod: 1.1, fordel: "Hurtig og udstyret med en kniv.", ulempe: "Tager mere skade.", baseEnergi: 9, synsRadius: 1, biomeMod: { 'bandit': -2 } },
    { id: 'explorer_m', navn: "Udforsker", ikon: "/game_faces/explorer_m.webp", startMsg: "Du kender terrænet.", startHp: 100, startGuld: 0, startUdstyr: ['skovl', 'klude', 'sovepose'], moveCost: 1, digCost: 3, dmgMod: 1.0, goldMod: 0.9, fordel: "Kan se langt og starter med en spade.", ulempe: "Mangler våben fra start.", baseEnergi: 7, synsRadius: 2, biomeMod: { 'hule': -2, 'ruin': -2 } },
    { id: 'explorer_f', navn: "Eventyrer", ikon: "/game_faces/explorer_f.webp", startMsg: "Du kender terrænet.", startHp: 100, startGuld: 0, startUdstyr: ['skovl', 'klude', 'sovepose'], moveCost: 1, digCost: 3, dmgMod: 1.0, goldMod: 0.9, fordel: "Kan se langt og starter med en spade.", ulempe: "Mangler våben fra start.", baseEnergi: 7, synsRadius: 2, biomeMod: { 'hule': -2, 'ruin': -2 } },
    { id: 'viking_m', navn: "Viking", ikon: "/game_faces/viking_m.webp", startMsg: "Hvile er for de svage.", startHp: 150, startGuld: 100, startUdstyr: ['oekse', 'klude'], moveCost: 1, digCost: 5, dmgMod: 0.9, goldMod: 1.0, fordel: "Enorm HP og tung økse.", ulempe: "Mangler sovepose, så kræver guld at sove.", baseEnergi: 8, synsRadius: 1, biomeMod: { 'slagmark': -2 } },
    { id: 'viking_f', navn: "Valkyrie", ikon: "/game_faces/viking_f.webp", startMsg: "Hvile er for de svage.", startHp: 150, startGuld: 100, startUdstyr: ['oekse', 'klude'], moveCost: 1, digCost: 5, dmgMod: 0.9, goldMod: 1.0, fordel: "Enorm HP og tung økse.", ulempe: "Mangler sovepose, så kræver guld at sove.", baseEnergi: 8, synsRadius: 1, biomeMod: { 'slagmark': -2 } },
    { id: 'royal_m', navn: "Hertug", ikon: "/game_faces/royal_m.webp", startMsg: "Penge løser alt.", startHp: 100, startGuld: 500, startUdstyr: ['flot_toej', 'sovepose'], moveCost: 1, digCost: 10, dmgMod: 1.1, goldMod: 1.2, fordel: "Masser af guld og fint tøj.", ulempe: "Intet våben. Gravning koster mere HP.", baseEnergi: 6, synsRadius: 1 },
    { id: 'royal_f', navn: "Hertuginde", ikon: "/game_faces/royal_f.webp", startMsg: "Penge løser alt.", startHp: 100, startGuld: 500, startUdstyr: ['flot_toej', 'sovepose'], moveCost: 1, digCost: 10, dmgMod: 1.1, goldMod: 1.2, fordel: "Masser af guld og fint tøj.", ulempe: "Intet våben. Gravning koster mere HP.", baseEnergi: 6, synsRadius: 1 },
    { id: 'hunter_m', navn: "Jæger", ikon: "/game_faces/hunter_m.webp", startMsg: "Hold afstand til byttet.", startHp: 90, startGuld: 20, startUdstyr: ['bue', 'klude', 'sovepose'], moveCost: 1, digCost: 6, dmgMod: 1.1, goldMod: 1.0, fordel: "Starter med bue og højt syn.", ulempe: "Lav start-HP.", baseEnergi: 8, synsRadius: 2, biomeMod: { 'skov': -2, 'blodskov': -2 } },
    { id: 'hunter_f', navn: "Skytte", ikon: "/game_faces/hunter_f.webp", startMsg: "Hold afstand til byttet.", startHp: 90, startGuld: 20, startUdstyr: ['bue', 'klude', 'sovepose'], moveCost: 1, digCost: 6, dmgMod: 1.1, goldMod: 1.0, fordel: "Starter med bue og højt syn.", ulempe: "Lav start-HP.", baseEnergi: 8, synsRadius: 2, biomeMod: { 'skov': -2, 'blodskov': -2 } },
    { id: 'pirate_m', navn: "Kaptajn", ikon: "/game_faces/pirate_m.webp", startMsg: "Havet tog alt andet.", startHp: 110, startGuld: 150, startUdstyr: ['sabel', 'klude'], moveCost: 1, digCost: 5, dmgMod: 1.0, goldMod: 1.2, fordel: "Høj startkapital og hurtig sabel.", ulempe: "Ingen sovepose.", baseEnergi: 7, synsRadius: 1, biomeMod: { 'hav': -3 } },
    { id: 'pirate_f', navn: "Korsar", ikon: "/game_faces/pirate_f.webp", startMsg: "Havet tog alt andet.", startHp: 110, startGuld: 150, startUdstyr: ['sabel', 'klude'], moveCost: 1, digCost: 5, dmgMod: 1.0, goldMod: 1.2, fordel: "Høj startkapital og hurtig sabel.", ulempe: "Ingen sovepose.", baseEnergi: 7, synsRadius: 1, biomeMod: { 'hav': -3 } },
    { id: 'dwarf_m', navn: "Dværg", ikon: "/game_faces/dwarf_m.webp", startMsg: "Klippen tygger knogler til støv.", startHp: 130, startGuld: 80, startUdstyr: ['skovl', 'oekse', 'klude'], moveCost: 1.5, digCost: 2, dmgMod: 1.0, goldMod: 1.3, fordel: "Mestergraver og guldjæger.", ulempe: "Tung og langsom at flytte.", baseEnergi: 7, synsRadius: 1, biomeMod: { 'bjerg': -3, 'krystal': -2 } },
    { id: 'dwarf_f', navn: "Minegraver", ikon: "/game_faces/dwarf_f.webp", startMsg: "Klippen tygger knogler til støv.", startHp: 130, startGuld: 80, startUdstyr: ['skovl', 'oekse', 'klude'], moveCost: 1.5, digCost: 2, dmgMod: 1.0, goldMod: 1.3, fordel: "Mestergraver og guldjæger.", ulempe: "Tung og langsom at flytte.", baseEnergi: 7, synsRadius: 1, biomeMod: { 'bjerg': -3, 'krystal': -2 } },
    { id: 'orc_m', navn: "Ork", ikon: "/game_faces/orc_m.webp", startMsg: "Smerte gør dig stærk.", startHp: 160, startGuld: 0, startUdstyr: ['svaerd', 'klude'], moveCost: 1, digCost: 6, dmgMod: 0.8, goldMod: 0.8, fordel: "Masser af liv og tyk hud.", ulempe: "Dårlig til at grave guld.", baseEnergi: 8, synsRadius: 1, biomeMod: { 'slagmark': -2 } },
    { id: 'orc_f', navn: "Klanleder", ikon: "/game_faces/orc_f.webp", startMsg: "Smerte gør dig stærk.", startHp: 160, startGuld: 0, startUdstyr: ['svaerd', 'klude'], moveCost: 1, digCost: 6, dmgMod: 0.8, goldMod: 0.8, fordel: "Masser af liv og tyk hud.", ulempe: "Dårlig til at grave guld.", baseEnergi: 8, synsRadius: 1, biomeMod: { 'slagmark': -2 } },
    { id: 'joker_m', navn: "Joker", ikon: "/game_faces/joker_m.webp", startMsg: "Held er en strategi.", startHp: 50, startGuld: 1, startUdstyr: ['kniv'], moveCost: 1, digCost: 5, dmgMod: 2.0, goldMod: 1.5, fordel: "Guldbonus og godt syn.", ulempe: "Tyndt helbred og tager dobbelt skade.", baseEnergi: 7, synsRadius: 2 },
    { id: 'joker_f', navn: "Harlekin", ikon: "/game_faces/joker_f.webp", startMsg: "Held er en strategi.", startHp: 50, startGuld: 1, startUdstyr: ['kniv'], moveCost: 1, digCost: 5, dmgMod: 2.0, goldMod: 1.5, fordel: "Guldbonus og godt syn.", ulempe: "Tyndt helbred og tager dobbelt skade.", baseEnergi: 7, synsRadius: 2 }
];